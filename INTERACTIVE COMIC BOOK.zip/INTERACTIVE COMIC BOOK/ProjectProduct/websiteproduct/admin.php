<?php
	session_start();
		if (@$_SESSION["admin"] == 0){
			header ("Location: login.php");
		}
		else{
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<title>Interactive Comic Book</title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="styles.css">
		<link rel="icon" type="image/png" href="">
		<script>
			var counter = 0;
			var lineSplit;
			
			function init(){
				expandMenu();
			}
			
			function expandMenu(){
				counter = counter + 1;
				if (counter % 2 == 0) {
					document.getElementById("sidebar").style.left = "-200px";
					document.getElementById("sidenav").style.left = "0px";
				} else {
					document.getElementById("sidebar").style.left = "0px";
					document.getElementById("sidenav").style.left = "200px";
				}
				
				//document.getElementById("counter").innerHTML = counter;
			}
			function dV(){
				
				var canvas = document.getElementById('myCanvas');
				var ctx = canvas.getContext('2d');
				var width = 20;
				var posX = 0;
				
				xhttp = new XMLHttpRequest();
				xhttp.addEventListener ("load", function() {
				var data = this.responseText.split("\n");
					for(var i=0; i < data.length-1; i++) {
						lineSplit = data[i].split(",");
						
						if(lineSplit[1] == undefined) {
							lineSplit[1] = 0;
						}
						
						var h = lineSplit[1]*10;
						ctx.fillStyle='#FF9A13';
						ctx.fillRect(posX, canvas.height - h, width, h);
						posX += width + 20;
						ctx.fillText("Prior Mood", 100, canvas.height - 100);
						
					}
				
			}
			);
			xhttp.open("GET", "unityproduct/InteractiveComicBook_Data/priorMoodRating.csv", false);
			xhttp.send();
						xhttp = new XMLHttpRequest();
						xhttp.addEventListener ("load", function() {
				var data = this.responseText.split("\n");
					for(var i=0; i < data.length-1; i++) {
						lineSplit = data[i].split(",");
						var h = lineSplit[1]*10;
						ctx.fillStyle='#21f380';
						ctx.fillRect(posX, canvas.height - h, width, h);
						posX += width + 20;
						ctx.fillText("New Mood", 500, canvas.height - 100);
					}
				
			}
			);
			xhttp.open("GET", "unityproduct/InteractiveComicBook_Data/newMoodRating.csv", false);
			xhttp.send();
			
			totals = {} ;
				var canvas = document.getElementById('myCanvas');
				var ctx = canvas.getContext('2d');
			xhttp = new XMLHttpRequest();
				xhttp.addEventListener ("load",function() {
					var panels = "";
					var data = this.responseText.split("\n");
					for(i=0; i < data.length-1; i++) {
						lineSplit = data[i].split(",");
					
						if(totals[lineSplit[1]] == undefined) {
							totals[lineSplit[1]] = 0;
						}
						
						panels += `Increasing totals for ${lineSplit[1]} by one<br />`;
						totals[lineSplit[1]]++;
						
					}
					for(index in totals) {
						panels += `${index} total = ${totals[index]}`;
						var h = totals[index]*10;
						ctx.fillStyle='red';
						ctx.fillRect(posX, canvas.height - h, width, h);
						posX += width + 20;
						
					}
					ctx.fillText("Animal Panel", posX - 150, canvas.height-100);
					ctx.fillText("Music Panel", posX - 100, canvas.height-50);
					ctx.fillText("Technology Panel", posX - 50, canvas.height-30);
					document.getElementById("myCanvas").innerHTML = panels;
					ctx.fillStyle= 'white';
					ctx.fillText("0",0, canvas.height - -1.5);
					ctx.fillText("1",0, canvas.height - 8.5);
					ctx.fillText("2",0, canvas.height - 18.5);
					ctx.fillText("3",0, canvas.height - 28.5);
					ctx.fillText("4",0, canvas.height - 38.5);
					ctx.fillText("5",0, canvas.height - 48.5);
					ctx.fillText("6",0, canvas.height - 58.5);
					ctx.fillText("7",0, canvas.height - 68.5);
					ctx.fillText("8",0, canvas.height - 78.5);
					ctx.fillText("9",0, canvas.height - 88.5);
					ctx.fillText("10",-2, canvas.height - 98.5);
					
					ctx.fillStyle='black';
					ctx.fillRect(10, canvas.height - 1, posX, 1);
					ctx.fillRect(10, canvas.height - 10, posX, 1);
					ctx.fillRect(10, canvas.height - 20, posX, 1);
					ctx.fillRect(10, canvas.height - 30, posX, 1);
					ctx.fillRect(10, canvas.height - 40, posX, 1);
					ctx.fillRect(10, canvas.height - 50, posX, 1);
					ctx.fillRect(10, canvas.height - 60, posX, 1);
					ctx.fillRect(10, canvas.height - 70, posX, 1);
					ctx.fillRect(10, canvas.height - 80, posX, 1);
					ctx.fillRect(10, canvas.height - 90, posX, 1);
					ctx.fillRect(10, canvas.height - 100, posX, 1);
					
						
				}
					
				);
				
				xhttp.open("GET", "unityproduct/InteractiveComicBook_Data/arrayobjects.csv", true);
				xhttp.send();
			
			}
			
		</script>
	</head>
	<body onload="dV()">
		<div id="wrapper">
			<aside>
				<div id="container">
					<div id="sidenav" onclick="init()">
						<span></span>
						<span></span>
						<span></span>
					</div>
				</div>
				<nav id="sidebar">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="data.html">Contextual Questionnaire</a></li>
						<li><a href="logout.php">Log Out</a></li>
					</ul>
				</nav>
			</aside>
			<section>
				<div id="counter">
				</div>
				<canvas id = "myCanvas" height="300" width="920">
				</canvas>
			</section>
			<section id="context">
				<table border="1">
					<tr>
						<th> Participant </th>
						<th> How did the game's colour scheme have an impact on your mood? </th>
						<th> Did the game encourage problem and puzzle solving skills? (1-9) </th>
						<th> Did the positive game messages, points and achievements entice you to keep playing? </th>
						<th> Did the game alleviate any negative feelings and emotions by envoking a positive emotional response such as happiness or fun? - How? </th>
						<th> Did the game cause any significant negative feelings and emotions such as sadness or frustration?  Why? </th>
						<th> How did the comic's colour scheme have an impact on your mood? </th>
						<th> Why did you choose a particular ending for the comic strip? And did you find it empowering to choose an ending of your choice? </th>
						<th> Did you find the comic strip to convey a positive message? (1-9) </th>
						<th> Did the comic alleviate any negative feelings and emotions by the message portrayed? - How? </th>
						<th> Did you find the use of a comic to be an appropriate medium to convey serious issues? - Why? </th>
					</tr>
						<?php
						$conn2 = new PDO ("mysql:host=localhost;dbname=crickg;", "crickg", "eechaeth");
									$results2 = $conn2->prepare("Select * From Participants Order by id");
									$results2->execute();
									$row = $results2->fetchAll(PDO::FETCH_ASSOC);
									$jsonE = json_encode($row);
									$jsonD = json_decode($jsonE, true);
									for($i=0; $i<count($jsonD); $i++)
									{
										$id = $jsonD[$i]["id"];
										echo "<tr>";
										echo "<td>" . $jsonD[$i]["id"] . "</td>" . "<td>" . $jsonD[$i]["q1"] . "</td>" . "<td>" . $jsonD[$i]["q2"] . "</td>". "<td>" . $jsonD[$i]["q3"] . "</td>". "<td>" . $jsonD[$i]["q4"] . "</td>". "<td>" . $jsonD[$i]["q5"] . "</td>". "<td>" . $jsonD[$i]["q6"] . "</td>". "<td>" . $jsonD[$i]["q7"] . "</td>". "<td>" . $jsonD[$i]["q8"] . "</td>". "<td>" . $jsonD[$i]["q9"] . "</td>". "<td>" . $jsonD[$i]["q0"] . "</td></tr>";
										
										
									}

						?>
				</table>
			</section>
		</div>
	</body>
</html>
<?php

		}
?>
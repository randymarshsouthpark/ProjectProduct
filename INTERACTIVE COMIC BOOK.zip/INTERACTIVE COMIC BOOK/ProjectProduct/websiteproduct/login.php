<?php
session_start();
$un = $_POST["username"];
$pw = $_POST["password"];

$conn=new PDO("mysql:host=localhost;dbname=crickg;","crickg","eechaeth");


$result=$conn->query("SELECT * FROM project_users WHERE username='$un' AND password='$pw'");
$row=$result->fetch();
if($row==false)
{
	echo "";
	
}
else
{	
	$_SESSION["administrator"] = $un;
	$_SESSION["admin"] = $row["admin"];
	header("Location: admin.php");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<title>Interactive Comic Book</title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="styles.css">
		<link rel="icon" type="image/png" href="">
		<script>
			var counter = 0;
			var lineSplit;
			
			function init(){
				expandMenu();
			}
			
			function expandMenu(){
				counter = counter + 1;
				if (counter % 2 == 0) {
					document.getElementById("sidebar").style.left = "-200px";
					document.getElementById("sidenav").style.left = "0px";
				} else {
					document.getElementById("sidebar").style.left = "0px";
					document.getElementById("sidenav").style.left = "200px";
				}
				
				//document.getElementById("counter").innerHTML = counter;
			}
		</script>
	</head>
	<body>
		<div id="wrapper">
			<aside>
				<div id="container">
					<div id="sidenav" onclick="init()">
						<span></span>
						<span></span>
						<span></span>
					</div>
				</div>
				<nav id="sidebar">
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="admin.php">Data Visualisation</a></li>
					</ul>
				</nav>
			</aside>
			<section>
				<div id="counter">
				</div>
			</section>
			<section>
				<form method="POST" action="login.php">
					<fieldset>
						<legend>Data Visualisation Login</legend>
							<label>Admin Username</label><br/>
							<input type="text" name="username"/><br/>
							<label>Admin Password</label><br/>
							<input type="password" name="password">
					</fieldset>
					<input type="submit" value="Submit"/>
				</form>
			</section>
		</div>
	</body>
</html>
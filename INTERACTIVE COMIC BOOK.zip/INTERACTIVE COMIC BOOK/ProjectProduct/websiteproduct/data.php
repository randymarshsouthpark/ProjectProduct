<?php
	$testq1 = htmlentities($_POST['q1']);
	$testq2 = htmlentities($_POST['q2']);
	$testq3 = htmlentities($_POST['q3']);
	$testq4 = htmlentities($_POST['q4']);
	$testq5 = htmlentities($_POST['q5']);
	$testq6 = htmlentities($_POST['q6']);
	$testq7 = htmlentities($_POST['q7']);
	$testq8 = htmlentities($_POST['q8']);
	$testq9 = htmlentities($_POST['q9']);
	$testq0 = htmlentities($_POST['q0']);

		if ($testq1 == "" || $testq2 == "" || $testq3 == "" || $testq4 == "" || $testq5 == "" || $testq6 == "" || $testq7 == "" || $testq8 == "" || $testq9 == "" || $testq0 == "")
		{
		echo "Answer Both Questions";
		} else {
			
			
			
			$conn = new PDO ("mysql:host=localhost;dbname=crickg;", "crickg", "eechaeth");
			$results = $conn->prepare("INSERT INTO Participants (q1, q2, q3, q4, q5, q6, q7, q8, q9, q0) VALUES (?,?,?,?,?,?,?,?,?,?)");
			$results->bindParam(1,$testq1);
			$results->bindParam(2,$testq2);
			$results->bindParam(3,$testq3);
			$results->bindParam(4,$testq4);
			$results->bindParam(5,$testq5);
			$results->bindParam(6,$testq6);
			$results->bindParam(7,$testq7);
			$results->bindParam(8,$testq8);
			$results->bindParam(9,$testq9);
			$results->bindParam(10,$testq0);
			$results->execute();
			
			
			header("Location: data.html");
			echo "Success";
			
			
			
			
			
			
		}
		
				
?>
﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

public class ComicEndings : MonoBehaviour
{
    public GameObject[] panels;
    string a1, a2, a3, a4;
    public SpriteRenderer sR;
    string arrayWriter;
    StreamWriter sW;
    public GameObject enCanvas;
    public Image endingPanel;
    public Sprite panel1;
    public Sprite panel2;
    public Sprite panel3;

    // Use this for initialization
    void Start()
    {
        arrayWriter = Application.dataPath + "/arrayobjects.csv";
        sW = new StreamWriter(arrayWriter, true);

    }

    // Update is called once per frame
    void Update()
    {

    }
    public void Awake()
    {
        panels = GameObject.FindGameObjectsWithTag("Panels");
        //Debug.Log(panels[0].name + " " + panels[1].name + " " + panels[2].name);
        

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.name == "Ending1")
        {
            sR = panels[2].GetComponent<SpriteRenderer>();
            sR.enabled = true;
        }
        if (collision.gameObject.name == "Ending2")
        {
            sR = panels[0].GetComponent<SpriteRenderer>();
            sR.enabled = true;
        }
        if (collision.gameObject.name == "Ending3")
        {
            sR = panels[1].GetComponent<SpriteRenderer>();
            sR.enabled = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.name == "Ending1")
        {
            sR = panels[2].GetComponent<SpriteRenderer>();
            sR.enabled = false;
        }
        if (collision.gameObject.name == "Ending2")
        {
            sR = panels[0].GetComponent<SpriteRenderer>();
            sR.enabled = false;
        }
        if (collision.gameObject.name == "Ending3")
        {
            sR = panels[1].GetComponent<SpriteRenderer>();
            sR.enabled = false;
        }
    }

    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == "Ending1")
        {
            //for (int k = 0; k < panels.Length; k++) {

            a4 = panels[2].name.ToString();
            Debug.Log("Comic No" + 1 + "is named" + a4);

            sW.WriteLine("Ending" + "," + a4);
            Debug.Log(a4 + " " + "has been written to file");
            sW.Flush();
            sW.Close();
            enCanvas.SetActive(true);
            Time.timeScale = 0f;
            endingPanel = endingPanel.GetComponent<Image>();
            endingPanel.sprite = panel1;


        }
        if (collision.gameObject.name == "Ending2")
        {
            //for (int k = 0; k < panels.Length; k++) {

            a4 = panels[0].name.ToString();
            Debug.Log("Comic No" + 2 + "is named" + a4);

            sW.WriteLine("Ending" + "," + a4);
            Debug.Log(a4 + " " + "has been written to file");
            sW.Flush();
            sW.Close();
            enCanvas.SetActive(true);
            Time.timeScale = 0f;
            endingPanel = endingPanel.GetComponent<Image>();
            endingPanel.sprite = panel2;


        }
        if (collision.gameObject.name == "Ending3")
        {
            //for (int k = 0; k < panels.Length; k++) {
            
            a4 = panels[1].name.ToString();
            Debug.Log("Comic No" + 3 + "is named" + a4);

            sW.WriteLine("Ending" + "," + a4);
            Debug.Log(a4 + " " + "has been written to file");
            sW.Flush();
            sW.Close();
            enCanvas.SetActive(true);
            Time.timeScale = 0f;
            endingPanel = endingPanel.GetComponent<Image>();
            endingPanel.sprite = panel3;
           

        }
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Finish : MonoBehaviour {

    public GameObject initCanvas;
    public GameObject canvasPanel;
    private Image panelColour;
    public GameObject moodPanel;
    public Button finishGame;
    public Text moodText;
    public InputField moodScore;
    public Button mood2;
    public CollisionDetection col;

    public static string newMood;
    private StreamWriter newSW;
    private string nString;

    private StreamWriter rewards;
    private string achievements;

    // Use this for initialization
    void Start () {
        nString = Application.dataPath + "/newMoodRating.csv";
        newSW = new StreamWriter(nString, true);
        //achievements = Application.dataPath + "/rewards.txt";
        //rewards = new StreamWriter(achievements, true);
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    private void Awake()
    {
        initCanvas.SetActive(false);

        //Setting the panel that the comic panels sit on
        panelColour = canvasPanel.GetComponent<Image>();
        panelColour.color = Color.cyan;

        //Setting the finishGame button
        finishGame.GetComponent<Button>().GetComponentInChildren<Text>().text = "Finish";
        finishGame.GetComponent<Button>().GetComponentInChildren<Text>().color = Color.black;
        finishGame.GetComponent<Button>().GetComponentInChildren<Text>().fontStyle = FontStyle.Bold;
        finishGame.GetComponent<Button>().GetComponentInChildren<Text>().fontSize = 16;
        panelColour = finishGame.GetComponent<Button>().GetComponentInChildren<Image>();
        panelColour.color = Color.white;

        //Setting the mood panel to false until user clicks the finishGame button
        panelColour = moodPanel.GetComponent<Image>();
        panelColour.color = Color.cyan;
        moodPanel.SetActive(false);

        //Mood Label
        moodText.GetComponent<Text>().text = "Please Rate Your Mood (1-9)";
        moodText.GetComponent<Text>().fontStyle = FontStyle.Bold;

        //Setting up the Input Field
        moodScore.GetComponent<InputField>().placeholder.GetComponent<Text>().text = "Mood Score";
        moodScore.characterLimit = 1;
        moodScore.contentType = InputField.ContentType.IntegerNumber;
        moodScore.onValidateInput += OnValidateInput;

        //Setting the mood1 button
        mood2.GetComponent<Button>().GetComponentInChildren<Text>().text = "Rate Mood";
        mood2.GetComponent<Button>().GetComponentInChildren<Text>().color = Color.black;
        mood2.GetComponent<Button>().GetComponentInChildren<Text>().fontStyle = FontStyle.Bold;
        mood2.GetComponent<Button>().GetComponentInChildren<Text>().fontSize = 16;
        panelColour = mood2.GetComponent<Button>().GetComponentInChildren<Image>();
        panelColour.color = Color.white;

    }
    public char OnValidateInput(string text, int index, char increment)
    {

        char positive = increment;

        if (increment != '1' && increment != '2' && increment != '3' && increment != '4' && increment != '5' && increment != '6' && increment != '7' && increment != '8' && increment != '9')
        {
            positive = '\0';
        }
        return positive;

    }

    public void FinishGame()
    {
        moodPanel.SetActive(true); 
    }

    public void OnSubmit()
    {
        if (moodScore.text == "" || moodScore.text == null)
        {
            Debug.Log("Error");
        }
        else
        {
            newMood = moodScore.text;
            Debug.Log(newMood);
            try
            {
                newSW.WriteLine("Mood" + "," + newMood);
            }
            finally
            {
                newSW.Flush();
                newSW.Close();
            }
           // try
           // {
                
            //        rewards.WriteLine(col.rewards[0].ToString());
           // }
          //  finally
          //  {
              //  rewards.Flush();
             //   rewards.Close();

                SceneManager.LoadScene("Progression", LoadSceneMode.Single);
           // }
        }
    }

}

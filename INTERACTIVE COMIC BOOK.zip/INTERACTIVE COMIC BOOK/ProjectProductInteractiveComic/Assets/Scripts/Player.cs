﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    protected MovementMotions playerMotions;

    // Use this for initialization
    void Start () {
        playerMotions = gameObject.GetComponentInParent<MovementMotions>();
	}

    private void OnCollisionEnter2D(Collision2D collision)
    {
        playerMotions.playerGrounded = true;
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        playerMotions.playerGrounded = true;
        playerMotions.linearDrag = 0f;
        
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        playerMotions.playerGrounded = false;
        playerMotions.linearDrag = 5f;
        
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingPlatform : MonoBehaviour
{

    private float platSpeed;
    private bool platMove;
    private GameObject coin;
    Vector3 coinMove;


    // Use this for initialization
    void Start()
    {
        coinMove = coin.transform.position - this.transform.position;
    }
    // Update is called once per frame
    void Update()
    {

        if (platMove) {
            Platform();
        }
        if (coin != null)
        {
            coin.transform.position = this.transform.position + coinMove;
        }


    }

    private void Awake()
    {
        platSpeed -= 2f;
        coin = GameObject.Find("Coin2");
    }

    void Platform() {
         transform.Translate(new Vector2(platSpeed * Time.deltaTime, 0));
    }

    public void OnCollisionStay2D(Collision2D collision)
    {
        
        if (collision.gameObject.tag == "Player")
        {
            platMove = true;
            collision.collider.transform.SetParent(transform);
        }

        if (collision.gameObject.name == "Invisible Object")
        {
            platSpeed = 0f;
            //Debug.Log("WHACK! - Moving Platform Cannot Pass!");

        }
    }

    public void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            platMove = false;
            collision.collider.transform.SetParent(null);
        }
    }

}

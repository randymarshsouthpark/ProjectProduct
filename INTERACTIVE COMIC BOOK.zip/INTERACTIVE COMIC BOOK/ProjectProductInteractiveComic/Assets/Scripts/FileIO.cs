﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FileIO : MonoBehaviour {

    public Finish finishScript;
    public string mood2;
    

	// Use this for initialization
	void Start () {

        mood2 = Finish.newMood;
        Debug.Log(mood2);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}

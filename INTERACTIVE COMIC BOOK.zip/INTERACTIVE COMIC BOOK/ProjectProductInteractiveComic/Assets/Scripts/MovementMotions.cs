﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovementMotions : MonoBehaviour {

    private float playerSpeed = 5f;
    private Rigidbody2D playerRigidbody;
    private float playerInput;
    private Vector2 playerAxis;
    private float jumpVelocity = 5f;
    public bool playerGrounded = false;
    private float gravityScale = 1.3f;
    public float linearDrag;
    public bool doubleJump;
    public bool jump = false;
    public bool jumpD = false;
    Quaternion originRot;
    private Animator animations;

    // Use this for initialization
    void Start () {
        playerRigidbody = gameObject.GetComponent<Rigidbody2D>();
        animations = GetComponent<Animator>();
    }
    private void Awake() {
        originRot = transform.rotation;
       
    }

    // Update is called once per frame
    void Update () {
        if (Input.GetButtonDown("Jump") && playerGrounded) {
            jump = true;
        } else if (Input.GetButtonDown("Jump") && !playerGrounded && doubleJump) {
            jumpD = true;
        }

        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
        {
            animations.Play("RunL");
            
        }
        else if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
        {
            animations.Play("Run");
        }
        else if (Input.GetKey(KeyCode.Space))
        {
            animations.Play("Jump");
        } else
        {
            animations.Play("Idle");
        }


        if (transform.rotation.z > 0 || transform.rotation.z < 0)
        {
            transform.rotation = originRot;
        }

        playerAxis = new Vector2(playerInput, 0f);
        playerInput = Input.GetAxis("Horizontal");
        //Debug.Log("Player Input: " + playerInput);


    }
    void FixedUpdate()
    {
        
        playerRigidbody.AddForce(playerAxis * playerSpeed);

        if (jump)
        {
            playerRigidbody.AddForce(Vector2.up * jumpVelocity / gravityScale, ForceMode2D.Impulse);
            playerRigidbody.drag = linearDrag;
            doubleJump = true;
            jump = false;
            Debug.Log("Jumping! Can Double Jump!");
        }
        if (jumpD)
        {
            playerRigidbody.AddForce(Vector2.up * (jumpVelocity / gravityScale) / 1.5f, ForceMode2D.Impulse);
            doubleJump = false;
            jumpD = false;
            Debug.Log("No Infinite Jumping!");
        }
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI : MonoBehaviour {
    
    private float aiSpeed = 3f;
    private int count;
    public SpriteRenderer spriteRend;
    

	// Use this for initialization
	void Start () {

        spriteRend = GetComponent<SpriteRenderer>();
        count = 0;
        spriteRend.flipX = true;
		
	}
   

    // Update is called once per frame
    void Update () {

        Movement();
        
	}
    public void Movement(){
        
        
            transform.Translate(new Vector2(aiSpeed * Time.deltaTime, 0));
        

    }

    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "AI")
        {
            aiSpeed *= -1f;
            count = count + 1;

            if (count % 2 == 0)
            {
                spriteRend.flipX = true;
                //Debug.Log("Counter Variable: " + count + " Moving Right");
            } else
            {
                spriteRend.flipX = false;
               // Debug.Log("Counter Variable: " + count + " Moving Left");
            }
            
        }
    }
}

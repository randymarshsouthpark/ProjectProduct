﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hit : MonoBehaviour {

    Rigidbody2D rigidBody;
    Vector3 originPos;
    private float mass = 0.5f;
    Quaternion originRot;


    // Use this for initialization
    void Start () {
        rigidBody = GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {

        if (transform.rotation.z > 0 || transform.rotation.z < 0)
        {
            transform.rotation = originRot;
        }


    }

    private void Awake()
    {
        originPos = new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z);
        originRot = transform.rotation;
    }


    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player") {

            rigidBody.mass = mass;
            
        }

        if (collision.gameObject.tag == "Enemy")
        {
            this.transform.position = originPos;
        }
    }
    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {

            rigidBody.mass = mass;

        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Respawn")
        {
            this.transform.position = originPos;
        }
    }
}

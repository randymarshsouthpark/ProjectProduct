﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InvisibleObject : MonoBehaviour {

    private SpriteRenderer rendObject;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void Awake()
    {
        rendObject = GetComponent<SpriteRenderer>();
        rendObject.enabled = false;
        
    }
}

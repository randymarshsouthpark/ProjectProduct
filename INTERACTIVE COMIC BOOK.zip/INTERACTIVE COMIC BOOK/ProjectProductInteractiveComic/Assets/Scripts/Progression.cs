﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using UnityEngine.SceneManagement;
using System;

public class Progression : MonoBehaviour {
    private Holder vHolder, h;
    public Text scoreProg, rewardProg;
    private FileStream loadFile;
    private BinaryFormatter scoreLoad;

    private StreamReader sR;
    private string readFile;
    private string line;

    private string jsonFile;
    private string json;

    public Button quitGame;
    private Image panelColour;


    // Use this for initialization
    void Start () {
        scoreLoad = new BinaryFormatter();
        loadFile = File.Open(Application.dataPath + "/loadScore.bin", FileMode.Open);
        vHolder = (Holder) scoreLoad.Deserialize(loadFile);
        loadFile.Flush();
        loadFile.Close();
        Debug.Log(loadFile.ToString() + vHolder.highScoreHolder);
        //scoreProg.text = "Score" + scoreLoad.ToString();

        line = "";
        readFile = Application.dataPath + "/rewards.txt";
        sR = new StreamReader(readFile, true);

        while (line != null)
        {
            line = sR.ReadLine();
            

            if (line != null)
            {
                rewardProg.GetComponent<Text>().text = line;
                rewardProg.GetComponent<Text>().fontStyle = FontStyle.Bold;
                Debug.Log(line);
            }
        }


        jsonFile = Application.dataPath + "/loadScore.json";
        json = File.ReadAllText(jsonFile);
        h = JsonUtility.FromJson<Holder>(json);
        Debug.Log(jsonFile + h.highScoreHolder);


        scoreProg.GetComponent<Text>().text = "Game Progression Rewards : " + h.highScoreHolder + "/40";
        scoreProg.GetComponent<Text>().fontStyle = FontStyle.Bold;


        //Setting the quitGame button
        quitGame.GetComponent<Button>().GetComponentInChildren<Text>().text = "Quit";
        quitGame.GetComponent<Button>().GetComponentInChildren<Text>().color = Color.black;
        quitGame.GetComponent<Button>().GetComponentInChildren<Text>().fontStyle = FontStyle.Bold;
        quitGame.GetComponent<Button>().GetComponentInChildren<Text>().fontSize = 16;
        panelColour = quitGame.GetComponent<Button>().GetComponentInChildren<Image>();
        panelColour.color = Color.white;



    }

    private void Awake()
    {
        rewardProg.GetComponent<Text>().text = "No Game Achievement Rewards";
    }

    // Update is called once per frame
    void Update () {
		
	}

    public void OnDestroy()
    {
        sR.Dispose();
        File.Delete(Application.dataPath + "/rewards.txt");
        //UnityEditor.EditorApplication.isPlaying = false;
        Application.Quit();

        

    }
}

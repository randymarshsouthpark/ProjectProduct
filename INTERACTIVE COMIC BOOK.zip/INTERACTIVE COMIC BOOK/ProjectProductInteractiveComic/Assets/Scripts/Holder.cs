﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class Holder {
    public int highScoreHolder;

    public Holder (int highScoreHolder) {

        this.highScoreHolder = highScoreHolder;

    }


}

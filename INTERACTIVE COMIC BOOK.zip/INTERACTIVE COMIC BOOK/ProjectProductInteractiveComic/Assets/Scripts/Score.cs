﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public class Score : MonoBehaviour {
    public Holder vHolder;
    public int score, highScore;
    private FileStream createFile;
    private BinaryFormatter scoreLoad;

    private StreamWriter sW;
    private string writeFile;

    private string jsonFile;
    private string json;

	// Use this for initialization
	void Start () {
        scoreLoad = new BinaryFormatter();
        createFile = File.Create((Application.dataPath + "/loadScore.bin"));
        writeFile = Application.dataPath + "/loadScore.txt";
        sW = new StreamWriter(writeFile, false);
        jsonFile = Application.dataPath + "/loadScore.json";
    }

    private void Awake()
    {
        score = 0;
        highScore = 0;
    }

    // Update is called once per frame
    void Update () {
        
	}

    private void OnDestroy()
    {
        try
        {
            if (score > highScore)
            {
                highScore = score;
            }
           
        } finally {
            vHolder = new Holder(highScore);
            scoreLoad.Serialize(createFile, vHolder);
            createFile.Flush();
            createFile.Close();          

            
            json = JsonUtility.ToJson(vHolder);
            File.WriteAllText(jsonFile, json);

            sW.Write(highScore);
            sW.Flush();
            sW.Close();

            Debug.Log(json);

            if (highScore == 0f)
            {
                Debug.Log("0% completed");
            } else if (highScore == 10f)
            {
                Debug.Log("25% completed");
            } else if (highScore == 20f)
            {
                Debug.Log("50% Completed");
            } else if (highScore == 30f)
            {
                Debug.Log("75% Completed");
            } else
            {
                Debug.Log("100% Completed");
            }
        }

        


    }

}

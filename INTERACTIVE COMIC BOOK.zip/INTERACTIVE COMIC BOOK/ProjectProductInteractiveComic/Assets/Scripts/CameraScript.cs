﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour {

    private GameObject player;
    private Vector3 Move;
    public int fps;
    private GameObject respawn;
    private SpriteRenderer respawnSprite;
    // Use this for initialization
    void Start () {

        
        Move = transform.position - player.transform.position;
        respawnSprite = respawn.GetComponent<SpriteRenderer>();
        respawnSprite.enabled = false;


    }

    private void Awake()
    {
        player = GameObject.Find("Player");
        respawn = GameObject.Find("Respawn");
        QualitySettings.vSyncCount = 0;
        fps = 60;
        

    }

    // Update is called once per frame
    void Update () {
        transform.position = player.transform.position + Move;

        if (Application.targetFrameRate != fps)
        {
            Application.targetFrameRate = fps;          
        }
        //Debug.Log("The target frame rate is: " + Application.targetFrameRate + " The current frame rate is " + fps);

    }
}

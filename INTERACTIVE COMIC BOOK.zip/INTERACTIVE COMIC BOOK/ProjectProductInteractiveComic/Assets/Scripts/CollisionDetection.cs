﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CollisionDetection : MonoBehaviour {

    public Score score;
    public SpriteRenderer sR;
    public GameObject pM, pM2, pM3, pM4, iO;
    Vector3 pMFollow;
    public ArrayList rewards;
    StreamWriter rewardStream;
    string achievements;
    private string arrayFile;

    // Use this for initialization
    void Start () {
        score = gameObject.GetComponentInParent<Score>();
        pMFollow = pM.transform.position - this.transform.position;
        pMFollow = pM2.transform.position - this.transform.position;
        pMFollow = pM3.transform.position - this.transform.position;
        pMFollow = pM4.transform.position - this.transform.position;
        rewards = new ArrayList();

        achievements = Application.dataPath + "/rewards.txt";
        rewardStream = new StreamWriter(achievements, true);

        



    }

    // Update is called once per frame
    void Update() {
        
        pM.transform.position = this.transform.position + pMFollow;
        pM2.transform.position = this.transform.position + pMFollow;
        pM3.transform.position = this.transform.position + pMFollow;
        pM4.transform.position = this.transform.position + pMFollow;

    }
    private void Awake()
    {
        pM = GameObject.Find("PositiveMessage");
        pM2 = GameObject.Find("PositiveMessage2");
        pM3 = GameObject.Find("PositiveMessage3");
        pM4 = GameObject.Find("PositiveMessage4");
        iO = GameObject.Find("Invisible Object");
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Respawn")
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            rewardStream.Dispose();
            File.Delete(Application.dataPath + "/rewards.txt");
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Enemy")
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            rewardStream.Dispose();
            File.Delete(Application.dataPath + "/rewards.txt");
        }
        if (collision.gameObject.tag == "Score")
        {
            score.score += 10;
            Debug.Log(score.score);
            Destroy(collision.gameObject);

            
            if (score.score == 10)
            {
                sR = pM.GetComponent<SpriteRenderer>();
                sR.enabled = true;
                Destroy(sR, 3.0f);
            }
            if (score.score == 20)
            {
                sR = pM2.GetComponent<SpriteRenderer>();
                sR.enabled = true;
                Destroy(sR, 3.0f);
            }
            if (score.score == 30)
            {
                sR = pM3.GetComponent<SpriteRenderer>();
                sR.enabled = true;
                Destroy(sR, 3.0f);
            }
            if (score.score == 40)
            {
                sR = pM4.GetComponent<SpriteRenderer>();
                sR.enabled = true;
                Destroy(sR, 3.0f);
            }

        }

        if (collision.gameObject.layer == 8)
        {
            rewards.Add("10 -- Rise Above Hate!");
            Debug.Log("RAH");

        }
        if (collision.gameObject.layer == 9)
        {
            rewards.Add("10 -- Daredevil!");
            Debug.Log("D");
        }
        if (collision.gameObject.layer == 10)
        {
            rewards.Add("10 -- A Flea Can Jump Over...The London Eye...?!");
            Debug.Log("AFCJOTLE");
        }
        if (collision.gameObject.layer == 11)
        {
            rewards.Add("10 -- A Start To Something Amazing!");
            Debug.Log("ASTSA");
        }
        if (collision.gameObject.name == "Invisible Object")
        {
            //Debug.Log("Nothing here!");
            Physics2D.IgnoreCollision(iO.GetComponent<Collider2D>(), this.GetComponent<Collider2D>());
        }
    }

    public void OnDestroy()
    {
        foreach (string points in rewards)
        {
                rewardStream.Write(points);
                
        }
        rewardStream.Flush();
        rewardStream.Close();

    }
    }


   

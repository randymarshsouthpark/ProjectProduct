﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayGame : MonoBehaviour {

    public GameObject canvasPanel;
    public Button playGame;
    public Button quitGame;
    public Text stageText;
    private Image panelColour;
    public GameObject moodPanel;
    public Text moodText;
    public InputField moodScore;
    public Button mood1;
    public GameObject loadPanel;
    public Slider loadingBar;
    private int productScenes;
    private float loadProgression;

    public static string priorMood;
    private StreamWriter priorSW;
    private string pString;



    private void Start()
    {
        pString = Application.dataPath + "/priorMoodRating.csv";
        priorSW = new StreamWriter(pString, true);
        
    }

    private void Awake()
    {
        //Setting the playGame button
        playGame.GetComponent<Button>().GetComponentInChildren<Text>().text = "Click to Find An Ending";
        playGame.GetComponent<Button>().GetComponentInChildren<Text>().color = Color.white;
        playGame.GetComponent<Button>().GetComponentInChildren<Text>().fontStyle = FontStyle.Bold;
        playGame.GetComponent<Button>().GetComponentInChildren<Text>().fontSize = 42;
        panelColour = playGame.GetComponent<Button>().GetComponentInChildren<Image>();
        panelColour.color = Color.black;

        //Setting the quitGame button
        quitGame.GetComponent<Button>().GetComponentInChildren<Text>().text = "Quit";
        quitGame.GetComponent<Button>().GetComponentInChildren<Text>().color = Color.black;
        quitGame.GetComponent<Button>().GetComponentInChildren<Text>().fontStyle = FontStyle.Bold;
        quitGame.GetComponent<Button>().GetComponentInChildren<Text>().fontSize = 16;
        panelColour = quitGame.GetComponent<Button>().GetComponentInChildren<Image>();
        panelColour.color = Color.white;

        //Stage Label
        stageText.GetComponent<Text>().text = "Stage 1";
        stageText.GetComponent<Text>().fontStyle = FontStyle.Bold;

        //Setting the panel that the comic panels sit on
        panelColour = canvasPanel.GetComponent<Image>();
        panelColour.color = Color.cyan;

        //Setting the mood panel to false until user clicks the playGame button
        panelColour = moodPanel.GetComponent<Image>();
        panelColour.color = Color.cyan;
        moodPanel.SetActive(false);

        //Mood Label
        moodText.GetComponent<Text>().text = "Please Rate Your Mood (1-9)";
        moodText.GetComponent<Text>().fontStyle = FontStyle.Bold;

        //Setting up the Input Field
        moodScore.GetComponent<InputField>().placeholder.GetComponent<Text>().text = "Mood Score";
        moodScore.characterLimit = 1;
        moodScore.contentType = InputField.ContentType.IntegerNumber;
        moodScore.onValidateInput += OnValidateInput;

        //Setting the mood1 button
        mood1.GetComponent<Button>().GetComponentInChildren<Text>().text = "Rate Mood";
        mood1.GetComponent<Button>().GetComponentInChildren<Text>().color = Color.black;
        mood1.GetComponent<Button>().GetComponentInChildren<Text>().fontStyle = FontStyle.Bold;
        mood1.GetComponent<Button>().GetComponentInChildren<Text>().fontSize = 16;
        panelColour = mood1.GetComponent<Button>().GetComponentInChildren<Image>();
        panelColour.color = Color.white;

        //Setting the load panel as false until user has entered their mood
        panelColour = loadPanel.GetComponent<Image>();
        panelColour.color = Color.cyan;
        loadPanel.SetActive(false);

        //Setting the load bar
        panelColour = loadingBar.GetComponent<Slider>().GetComponentInChildren<Image>();
        panelColour.color = Color.green;

        panelColour = loadingBar.fillRect.GetComponentInChildren<Image>();
        panelColour.color = Color.red;

        loadingBar.interactable = false;


    }

    public void Mood()
    {
        //Activates the mood panel
        moodPanel.SetActive(true);
    }
    public void Destroy()
    {
        //UnityEditor.EditorApplication.isPlaying = false;
        Application.Quit();
    }

    protected void LoadBar()
    {
        //Activates the load panel
        loadPanel.SetActive(true);
        loadingBar.value = loadProgression;
    }

    public void LoadGame(int productScenes)
    {
        if (moodScore.text == "" || moodScore.text == null)
        {
            Debug.Log("Error - No Characters Entered");

        }
        else
        {
            this.productScenes = productScenes;
            StartCoroutine(LevelLoader(productScenes));
            PriorMoodRating();
            Debug.Log(priorMood);

            try {
                priorSW.WriteLine("Mood" + "," + priorMood);
            } finally {
                priorSW.Flush();
                priorSW.Close();
            }

        }

    }

    private void PriorMoodRating()
    {
        priorMood = moodScore.text;
        moodPanel.SetActive(false);
    }

    public char OnValidateInput(string text, int index, char increment)
    {

        char positive = increment;

        if (increment != '1' && increment != '2' && increment != '3' && increment != '4' && increment != '5' && increment != '6' && increment != '7' && increment != '8' && increment != '9')
        {
            Debug.Log("Invalid Character" + " " + positive.ToString());
            positive = '\0';
        }
        return positive;

    }

    IEnumerator LevelLoader(int productScenes)
    {
        this.productScenes = productScenes;

        AsyncOperation scenes = SceneManager.LoadSceneAsync(productScenes);

        while (scenes.isDone == false)
        {
            loadProgression = scenes.progress;
            //Calling the load bar method
            LoadBar();

            //Debug.Log(loadProgression);

            Debug.Log("Game took " + Time.deltaTime + " seconds to load");

            //Returns null until the game has loaded
            yield return null;
        }
        scenes.allowSceneActivation = true;



    }
}
